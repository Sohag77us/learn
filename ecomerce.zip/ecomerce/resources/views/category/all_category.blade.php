@extends('layouts.app')
@section('content')
<div class="content-page">
    <div class="content">
        <div class="container">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Welcome !</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="#">Echobvel</a></li>
                        <li class="active">IT</li>
                    </ol>
                </div>
            </div>

            <!-- Start Widget -->
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">All Category</h3>
                            <a href="{{ route('add.category') }}" class="btn btn-sm btn-info pull-right">Add New</a>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <table id="datatable" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Category Name</th>
                                                <th>Category Description</th>
                                                 <th>Created Time</th>
                                                <th>Publication Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                              <tr>
                                                @foreach ($categoryes as $categorye)
                                                      <td>{{$categorye->category_name}}</td>
                                                      <td>{{$categorye->category_description}}</td>
                                                        <td>{{ $categorye->created_at->diffForHumans()}}</td>
                                                        <td>
                                                           @if ($categorye->status==1 )
                                                           <a class="btn btn-success" href="#">Published</a>
                                                           @else
                                                           <a class="btn btn-warning" href="#">Unublished</a>
                                                           @endif
                                                       </td>

                                                       <td>
                                   <div class="btn-group" role="group" aria-label="Basic example">
                                       @if ($categorye->status==1)
                                       <a class="btn btn-info" href="{{ url('category/unpublish',['cat_id'=>$categorye->id]) }}">Unublished</a>

                                       @else
                                       <a class="btn btn-info" href="{{ url('category/publish',['cat_id'=>$categorye->id]) }}">Published</a>
                                       @endif
                                       <a class="btn btn-success" href="{{ url('edit/category') }}/{{$categorye->id }}">Edit</a>
                                       <a class="btn btn-danger" href="{{ url('delete-category') }}/{{$categorye->id }}">Delete</a>

                                   </div>
                               </td>
                                            </tr>
                                          @endforeach


                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- container -->
    </div> <!-- content -->
</div>
@endsection
@section('footer')
<script>
    $(document).ready(function() {
        $('.delete_link').click(function() {
            var redirect_link = $(this).val();
            Swal.fire({
                title: 'Are you sure?',
                text: "You want to Delete!",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes!'
            }).then((result) => {
                if (result.value) {
                    window.location.href = redirect_link;
                }
            })
        });
    });
</script>
@endsection
