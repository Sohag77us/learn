<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\category;
use Image;
use App\Prodcut;
use DB;
use Carbon\Carbon;
class ProductController extends Controller
{
  public function AddProduct() {
  $categoryname=Category::all();
   return view('product/add_product',compact('categoryname'));
  }

  public function Store(Request $request) {
           $request->validate([
          'product_name' => 'required',
          'cat_id' => 'required',
          'product_des' => 'required',
          'product_price' => 'required|integer',
          'status' => 'required',
           ]);

      $last_insert_id= DB::table('prodcuts')->insertGetId([
           'product_name' =>$request->product_name,
           'cat_id' =>$request->cat_id,
           'product_des' =>$request->product_des,
           'product_price' =>$request->product_price,
           'status' =>$request->status,
             ]);

          if ($request->hasFile('product_image')) {
           $fileName= $last_insert_id.'.'.$request->product_image->getClientOriginalExtension();

           Image::make($request->product_image)->save(base_path('public/uploads/product_images/'.$fileName));

           DB::table('prodcuts')
               ->where('id', $last_insert_id)
               ->update([
                 'product_image' => $fileName,
               ]);
            }

                 if ($last_insert_id) {
                 $notification=array(
                           'messege'=>'Post Added Successfully',
                           'alert-type'=>'success'
                            );
                  	return back()->with($notification);
                  }
                  else{
                  	return back();
                  }
         }

                 public function AllProduct()
                     {
                     $products = Prodcut::orderBy('id', 'desc')->get();
                    return view('product/all_product',compact('products'));
                     }

             public function ProductUnpublish($pro_id){
                    $product = Prodcut::find($pro_id);
                      $product->status= 2;
                      $product->save();
                      return back();
                    }


                  public function ProductPpublish($pro_id){
                    $product = Prodcut::find($pro_id);
                      $product->status= 1;
                      $product->save();
                      return back();
                    }

              public function DeleteProduct($pro_id) {
                $prodcut=Prodcut::find($pro_id);
                 if ($prodcut->product_image == 'default_image.jpg') {
                     $prodcut->delete();
                 }else{
                   unlink(base_path('public/uploads/product_images/'.$prodcut->product_image));
                  $prodcut->delete();
                 }
                 return back();

               }


                       public function EditProduct($pro_id) {

                           $categoryname = DB::table('categories')->where('status',1)->get();
                         $product = DB::table('prodcuts')->where('id',$pro_id)->first();

                        return view('product/edit_product',['categoryname'=>$categoryname,'product'=>  $product]);
                       }


             public function UpdateProduct(Request $request) {


               $product = DB::table('prodcuts')->where('id',$request->product_id)->update([
                 'product_name' =>$request->product_name,
                 'cat_id' =>$request->cat_id,
                 'product_des' =>$request->product_des,
                 'product_price' =>$request->product_price,
                 'status' =>$request->status,
               ]);


               if ($request->hasFile('product_image')) {

                   $product = Prodcut::find($request->product_id);
                   if ($product->product_image == 'default_image.jpg') {
                     $fileName= $request->product_id.'.'.$request->product_image->getClientOriginalExtension();
                     Image::make($request->product_image)->save(base_path('public/uploads/product_images/'.$fileName));
                     DB::table('products')->where('id', $request->product_id)->update([
                           'product_image' => $fileName,
                         ]);
                   }else{
                     unlink(base_path('public/uploads/product_images/'.$product ->product_image));
                     $fileName= $request->product_id.'.'.$request->product_image->getClientOriginalExtension();
                     Image::make($request->product_image)->resize(268, 249)->save(base_path('public/uploads/product_images/'.$fileName));
                     DB::table('prodcuts')->where('id', $request->product_id)->update([
                           'product_image' => $fileName,
                         ]);
                   }


                 }
                     if ($product) {
                     $notification=array(
                               'messege'=>'Post Added Successfully',
                               'alert-type'=>'success'
                                );
                      	return back()->with($notification);
                      }
                      else{
                      	return back();
                      }

           }

}
