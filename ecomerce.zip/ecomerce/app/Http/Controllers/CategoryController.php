<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use Carbon\Carbon;
class CategoryController extends Controller
{
  public function AddCategory() {
   return view('category/add_category');
  }

  public function AllCategory() {

  $categoryes = Category::all();
   return view('category/all_category',compact('categoryes'));
  }

  public function store(Request $request) {
      $request->validate([
     'category_name' => 'required|unique:categories',
     'category_description' => 'required',
     'status' => 'required',
      ]);
       $category = new Category;
       $category->category_name=$request->category_name;
       $category->category_description=$request->category_description;
       $category->status=$request->status;
       $category->save();

       if ($category->save()) {
       $notification=array(
                 'messege'=>'Post Added Successfully',
                 'alert-type'=>'success'
                  );
        	return back()->with($notification);
        }
        else{
        	return back();
        }
       }

         public function CategoryUnpublish($cat_id){
          $category = Category::find($cat_id);
          $category->status= 2;
          $category->save();
          return back();
        }

        public function CategoryPublish($cat_id) {
         $category = Category::find($cat_id);
         $category->status= 1;
         $category->save();
         return back();
       }

         public function EditCategory($cat_id) {
          $category = Category::find($cat_id);
         return view('category/edit_category',compact('category'));
        }

        public function UpdateCategory(Request $request) {
           $request->validate([
          'category_name' => 'required',
          'category_description' => 'required',
          'status' => 'required',
           ]);
            $category = Category::find($request->category_id);
            $category->category_name=$request->category_name;
            $category->category_description=$request->category_description;
            $category->status=$request->status;
            $category->save();

            if ($category->save()) {
            $notification=array(
                      'messege'=>'up Added Successfully',
                      'alert-type'=>'success'
                       );
                     //return Redirect()->route('all.employee')->with($notification);
              return back()->with($notification);
             }
             else{
              return back();
             }
            }


            public function DeleteCategory($cat_id){
        Category::find($cat_id)->delete();
        return back();

        }



}
