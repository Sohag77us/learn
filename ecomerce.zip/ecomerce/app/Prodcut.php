<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Prodcut extends Model
{
  public function RealtionToCategory()
{
return $this->hasOne('App\Category', 'id', 'cat_id');
}//
}
