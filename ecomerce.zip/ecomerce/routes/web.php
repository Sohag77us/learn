<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

//EMPLOYEE ROUTES ARE HERE--------------------
Route::get('/add-category', 'CategoryController@AddCategory')->name('add.category');
Route::post('/insert-category','CategoryController@store');
Route::get('/all-category', 'CategoryController@AllCategory')->name('all.category');
Route::get('category/unpublish/{cat_id}', 'CategoryController@CategoryUnpublish');
Route::get('category/publish/{cat_id}', 'CategoryController@CategoryPublish');
Route::get('/edit-category/{id}', 'CategoryController@EditCategory');
Route::post('category-update','CategoryController@UpdateCategory');
Route::get('/delete-category/{cat_id}', 'CategoryController@DeleteCategory');

//EMPLOYEE ROUTES ARE HERE--------------------
Route::get('add-product', 'ProductController@AddProduct')->name('add.product');
Route::post('insert-product', 'ProductController@Store');
Route::get('all/product', 'ProductController@AllProduct')->name('all.product');

Route::get('product/unpublish/{pro_id}', 'ProductController@ProductUnpublish');
Route::get('product/publish/{pro_id}', 'ProductController@ProductPpublish');

Route::get('delete/product/{pro_id}', 'ProductController@DeleteProduct');
Route::get('edit/product/{pro_id}', 'ProductController@EditProduct');
Route::post('update/product', 'ProductController@UpdateProduct');
